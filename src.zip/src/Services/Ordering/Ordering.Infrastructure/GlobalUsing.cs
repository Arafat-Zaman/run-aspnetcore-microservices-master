﻿global using Ordering.Infrastructure.Data;
global using Ordering.Infrastructure.Data.Interceptors;
global using Microsoft.EntityFrameworkCore;
global using Ordering.Domain.Models;
global using Ordering.Domain.ValueObjects;
global using Ordering.Domain.Abstractions;
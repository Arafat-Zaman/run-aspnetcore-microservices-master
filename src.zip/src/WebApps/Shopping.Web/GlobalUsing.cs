﻿global using Shopping.Web.Models.Catalog;
global using Shopping.Web.Models.Basket;
global using Shopping.Web.Models.Ordering;
global using Refit;
global using Shopping.Web.Services;
global using Microsoft.AspNetCore.Mvc;
global using Microsoft.AspNetCore.Mvc.RazorPages;
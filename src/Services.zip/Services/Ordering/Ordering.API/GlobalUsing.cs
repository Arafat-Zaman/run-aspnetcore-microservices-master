﻿global using Carter;
global using Mapster;
global using MediatR;
global using Ordering.Application.Dtos;